Instructions:
1. Open createDatabase.sql.
2. For create tables wired, wirelss and accessories; change all the product types inside ENUMs
3. Run createDatabase.sql.
